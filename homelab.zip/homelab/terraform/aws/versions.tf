terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
  # 처음엔 로컬 state로 시작 → 7주차 고장 과제에서 S3 backend(use_lockfile)로 옮기며 state 개념 학습
  # backend "s3" {
  #   bucket       = "<내계정>-homelab-tfstate"
  #   key          = "aws/terraform.tfstate"
  #   region       = "ap-northeast-2"
  #   use_lockfile = true
  # }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project   = "homelab"
      ManagedBy = "terraform"
    }
  }
}
