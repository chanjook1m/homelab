output "github_role_arn" {
  description = "GitHub 저장소 Variables의 AWS_GHA_ROLE_ARN에 넣을 값"
  value       = aws_iam_role.gha_ecr_push.arn
}

output "ecr_repository_url" {
  value = aws_ecr_repository.app.repository_url
}

output "ec2_instance_id" {
  value = try(aws_instance.k3s[0].id, "꺼져 있음 (enable_ec2=false)")
}
