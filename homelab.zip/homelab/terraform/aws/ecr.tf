resource "aws_ecr_repository" "app" {
  name                 = "homelab/osi-shop"
  image_tag_mutability = "IMMUTABLE" # 같은 태그 덮어쓰기 금지 — 배포 추적성
  force_delete         = true        # 실습 후 destroy 편하게 (운영에선 false)
  image_scanning_configuration {
    scan_on_push = true
  }
}

# 저장 용량 과금(GB-월)을 막는 수명 주기: 최근 10개만 유지
resource "aws_ecr_lifecycle_policy" "app" {
  repository = aws_ecr_repository.app.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "keep last 10"
      selection    = { tagStatus = "any", countType = "imageCountMoreThan", countNumber = 10 }
      action       = { type = "expire" }
    }]
  })
}
