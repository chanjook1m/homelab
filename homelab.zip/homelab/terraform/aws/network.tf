# NAT 게이트웨이 없음(시간당 약 $0.045 + 데이터 처리 비용) → 퍼블릭 서브넷 하나에 EC2를 두고
# 인바운드는 전부 닫음. 접속은 Tailscale(아웃바운드 연결)로만. 비용과 공격면을 동시에 줄이는 설계
resource "aws_vpc" "main" {
  cidr_block           = "10.40.0.0/16" # 홈랩(192.168.64.0/24)·Pod(10.244.0.0/16)와 겹치지 않게
  enable_dns_hostnames = true
  tags                 = { Name = "homelab" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
}

data "aws_availability_zones" "az" {
  state = "available"
}

resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.40.1.0/24"
  availability_zone       = data.aws_availability_zones.az.names[0]
  map_public_ip_on_launch = true # 퍼블릭 IPv4는 시간당 $0.005 과금 — EC2를 끄면 같이 사라짐
  tags                    = { Name = "homelab-public" }
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }
}

resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

resource "aws_security_group" "node" {
  name        = "homelab-node"
  description = "No inbound. Egress only (Tailscale, package repos, ECR)"
  vpc_id      = aws_vpc.main.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  # ingress 블록 없음 = 22번 포트도 닫힘. 관리 접속은 SSM Session Manager 또는 Tailscale
}
