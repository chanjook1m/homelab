# 7주차: 클라우드 쪽 k3s 노드 1대. enable_ec2=false면 아무것도 만들지 않음 (비용 0)
data "aws_ssm_parameter" "ubuntu_arm" {
  name = "/aws/service/canonical/ubuntu/server/24.04/stable/current/arm64/hvm/ebs-gp3/ami-id"
}

data "aws_iam_policy_document" "ec2_trust" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

# 인스턴스 프로파일: EC2 안의 프로그램(Crossplane 등)이 키 없이 AWS API를 부르는 방법
resource "aws_iam_role" "node" {
  name               = "homelab-cloud-node"
  assume_role_policy = data.aws_iam_policy_document.ec2_trust.json
}

resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore" # SSH 대신 Session Manager
}

data "aws_iam_policy_document" "node_extra" {
  statement {
    sid       = "ReadTailscaleKey"
    actions   = ["ssm:GetParameter"]
    resources = ["arn:aws:ssm:${var.region}:${data.aws_caller_identity.me.account_id}:parameter${var.tailscale_auth_key_ssm_param}"]
  }
  statement {
    sid       = "CrossplaneEcrOnly"
    actions   = ["ecr:CreateRepository", "ecr:DeleteRepository", "ecr:DescribeRepositories", "ecr:TagResource", "ecr:ListTagsForResource", "ecr:PutLifecyclePolicy", "ecr:GetLifecyclePolicy", "ecr:DeleteLifecyclePolicy"]
    resources = ["arn:aws:ecr:${var.region}:${data.aws_caller_identity.me.account_id}:repository/team-*"] # Crossplane은 team-* 저장소만
  }
  statement {
    sid       = "EcrPull"
    actions   = ["ecr:GetAuthorizationToken", "ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer"]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "node_extra" {
  role   = aws_iam_role.node.id
  policy = data.aws_iam_policy_document.node_extra.json
}

resource "aws_iam_instance_profile" "node" {
  name = "homelab-cloud-node"
  role = aws_iam_role.node.name
}

resource "aws_instance" "k3s" {
  count                  = var.enable_ec2 ? 1 : 0
  ami                    = data.aws_ssm_parameter.ubuntu_arm.value
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public.id
  vpc_security_group_ids = [aws_security_group.node.id]
  iam_instance_profile   = aws_iam_instance_profile.node.name

  metadata_options {
    http_tokens                 = "required" # IMDSv2 강제 — SSRF로 자격증명 탈취 방지 (Capital One 사고 교훈)
    http_put_response_hop_limit = 2          # 컨테이너 안에서도 IMDS 접근 가능하게(1이면 Pod에서 실패 → 고장 과제)
  }

  root_block_device {
    volume_size = 20
    volume_type = "gp3"
    encrypted   = true
  }

  user_data = templatefile("${path.module}/user-data.sh.tftpl", {
    region    = var.region
    ssm_param = var.tailscale_auth_key_ssm_param
  })

  tags = { Name = "homelab-cloud-k3s" }
}
