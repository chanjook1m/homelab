variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "github_repo" {
  description = "OIDC로 ECR 푸시를 허용할 저장소 (owner/name)"
  type        = string
}

variable "budget_email" {
  description = "예산 초과 알림을 받을 이메일"
  type        = string
}

variable "monthly_budget_usd" {
  type    = number
  default = 10
}

variable "enable_ec2" {
  description = "클라우드 k3s 노드를 켤지. 실습할 때만 true → apply, 끝나면 false → apply"
  type        = bool
  default     = false
}

variable "instance_type" {
  type    = string
  default = "t4g.small" # arm64, 2 vCPU / 2 GiB. 서울 온디맨드 약 $0.0208/시간
}

variable "tailscale_auth_key_ssm_param" {
  description = "Tailscale 일회용 인증키를 넣어둔 SSM SecureString 이름 (값은 콘솔/CLI로 직접 넣고 Git에 두지 않음)"
  type        = string
  default     = "/homelab/tailscale-authkey"
}
