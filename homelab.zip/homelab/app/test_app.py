"""단위 테스트: python3 -m unittest -v (app 폴더에서). CI 첫 단계에서 실행합니다."""
import json, os, threading, time, unittest, urllib.request
os.environ.setdefault("PORT", "18080")
import app  # noqa: E402

class AppTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from http.server import ThreadingHTTPServer
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 18080), app.Handler)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        time.sleep(0.2)

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def get(self, path):
        with urllib.request.urlopen("http://127.0.0.1:18080" + path, timeout=3) as r:
            return r.status, r.read().decode()

    def test_health(self):
        self.assertEqual(self.get("/healthz")[0], 200)

    def test_ready_without_redis(self):
        self.assertEqual(self.get("/readyz")[0], 200)

    def test_products(self):
        code, body = self.get("/api/products")
        self.assertEqual(code, 200)
        self.assertEqual(len(json.loads(body)["products"]), 3)

    def test_metrics(self):
        self.get("/api/products")
        self.assertIn("http_requests_total", self.get("/metrics")[1])

if __name__ == "__main__":
    unittest.main()
