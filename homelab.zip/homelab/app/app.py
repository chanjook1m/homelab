"""osi-shop: DevOps 실습용 쇼핑몰 API (표준 라이브러리만 사용)
GET / · GET /api/products · POST /api/orders · GET /api/orders · /healthz · /readyz · /metrics
환경변수: PORT VERSION LOG_LEVEL REDIS_HOST REDIS_PORT ERROR_RATE SLOW_MS DRAIN_SECONDS
"""
import json, logging, os, random, signal, socket, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.getenv("PORT", "8080"))
VERSION = os.getenv("VERSION", "v1")
REDIS_HOST = os.getenv("REDIS_HOST", "")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
ERROR_RATE = float(os.getenv("ERROR_RATE", "0"))
SLOW_MS = int(os.getenv("SLOW_MS", "0"))
DRAIN_SECONDS = int(os.getenv("DRAIN_SECONDS", "5"))
HOSTNAME = socket.gethostname()

PRODUCTS = [
    {"id": 1, "name": "기계식 키보드", "price": 89000},
    {"id": 2, "name": "무선 마우스", "price": 39000},
    {"id": 3, "name": "27인치 모니터", "price": 259000},
]

# ---- 로그: JSON 한 줄
class JsonFormatter(logging.Formatter):
    def format(self, r):
        d = {"time": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "level": r.levelname, "msg": r.getMessage(),
             "pod": HOSTNAME, "version": VERSION}
        d.update(getattr(r, "extra_fields", {}))
        return json.dumps(d, ensure_ascii=False)

log = logging.getLogger("osi-shop")
_h = logging.StreamHandler(sys.stdout); _h.setFormatter(JsonFormatter())
log.addHandler(_h); log.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())

def logx(level, msg, **kw):
    log.log(level, msg, extra={"extra_fields": kw})

# ---- 아주 작은 Redis 클라이언트 (RESP 프로토콜)
class Redis:
    def __init__(self, host, port):
        self.host, self.port, self.lock = host, port, threading.Lock()

    def cmd(self, *args):
        payload = f"*{len(args)}\r\n" + "".join(f"${len(str(a).encode())}\r\n{a}\r\n" for a in args)
        with self.lock, socket.create_connection((self.host, self.port), timeout=2) as s:
            s.sendall(payload.encode())
            return self._read(s.makefile("rb"))

    def _read(self, f):
        line = f.readline().rstrip(b"\r\n")
        t, rest = line[:1], line[1:]
        if t == b"+": return rest.decode()
        if t == b"-": raise RuntimeError(rest.decode())
        if t == b":": return int(rest)
        if t == b"$":
            n = int(rest)
            return None if n == -1 else f.read(n + 2)[:-2].decode()
        if t == b"*": return [self._read(f) for _ in range(int(rest))]
        raise RuntimeError("unknown reply")

class Store:
    """REDIS_HOST가 있으면 Redis, 없으면 메모리에 주문 저장"""
    def __init__(self):
        self.redis = Redis(REDIS_HOST, REDIS_PORT) if REDIS_HOST else None
        self.mem = []
    def ready(self):
        if not self.redis: return True
        try: return self.redis.cmd("PING") == "PONG"
        except Exception: return False
    def add(self, order):
        if self.redis: self.redis.cmd("LPUSH", "orders", json.dumps(order, ensure_ascii=False))
        else: self.mem.insert(0, order)
    def recent(self):
        if self.redis: return [json.loads(x) for x in self.redis.cmd("LRANGE", "orders", 0, 19)]
        return self.mem[:20]

store = Store()

# ---- Prometheus 지표 (텍스트 형식)
BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5]
metrics_lock = threading.Lock()
req_total, dur_buckets, dur_sum, dur_count, orders_total = {}, {}, {}, {}, [0]

def observe(method, path, status, seconds):
    with metrics_lock:
        k = (method, path, str(status)); req_total[k] = req_total.get(k, 0) + 1
        b = dur_buckets.setdefault(path, [0] * (len(BUCKETS) + 1))
        for i, le in enumerate(BUCKETS):
            if seconds <= le: b[i] += 1
        b[-1] += 1
        dur_sum[path] = dur_sum.get(path, 0) + seconds
        dur_count[path] = dur_count.get(path, 0) + 1

def render_metrics():
    out = ["# TYPE app_info gauge", f'app_info{{version="{VERSION}"}} 1', "# TYPE http_requests_total counter"]
    with metrics_lock:
        for (m, p, s), v in sorted(req_total.items()):
            out.append(f'http_requests_total{{method="{m}",path="{p}",status="{s}"}} {v}')
        out.append("# TYPE http_request_duration_seconds histogram")
        for p, b in sorted(dur_buckets.items()):
            for i, le in enumerate(BUCKETS):
                out.append(f'http_request_duration_seconds_bucket{{path="{p}",le="{le}"}} {b[i]}')
            out.append(f'http_request_duration_seconds_bucket{{path="{p}",le="+Inf"}} {b[-1]}')
            out.append(f'http_request_duration_seconds_sum{{path="{p}"}} {dur_sum[p]:.6f}')
            out.append(f'http_request_duration_seconds_count{{path="{p}"}} {dur_count[p]}')
        out += ["# TYPE shop_orders_total counter", f"shop_orders_total {orders_total[0]}"]
    return "\n".join(out) + "\n"

# ---- HTTP 핸들러
draining = threading.Event()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, status, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else (body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)).encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Pod", HOSTNAME)
        self.end_headers()
        self.wfile.write(data)
        return status

    def handle_one(self, method):
        t0 = time.time(); path = self.path.split("?")[0]; status = 500
        try:
            if path == "/healthz":
                status = self.send(200, {"status": "alive"})
            elif path == "/readyz":
                ok = store.ready() and not draining.is_set()
                status = self.send(200 if ok else 503, {"ready": ok, "draining": draining.is_set()})
            elif path == "/metrics":
                status = self.send(200, render_metrics(), "text/plain; version=0.0.4")
            elif path.startswith("/api/"):
                if SLOW_MS: time.sleep(SLOW_MS / 1000)
                if ERROR_RATE and random.random() * 100 < ERROR_RATE:
                    status = self.send(500, {"error": "injected failure"})
                elif path == "/api/products" and method == "GET":
                    status = self.send(200, {"version": VERSION, "pod": HOSTNAME, "products": PRODUCTS})
                elif path == "/api/orders" and method == "GET":
                    status = self.send(200, {"orders": store.recent()})
                elif path == "/api/orders" and method == "POST":
                    n = int(self.headers.get("Content-Length", 0))
                    req = json.loads(self.rfile.read(n) or b"{}")
                    p = next((x for x in PRODUCTS if x["id"] == int(req.get("product_id", 0))), None)
                    if not p:
                        status = self.send(400, {"error": "unknown product_id"})
                    else:
                        order = {"product": p["name"], "qty": int(req.get("qty", 1)), "at": time.strftime("%H:%M:%S"), "pod": HOSTNAME}
                        store.add(order)
                        with metrics_lock: orders_total[0] += 1
                        status = self.send(201, order)
                else:
                    status = self.send(404, {"error": "not found"})
            elif path == "/":
                rows = "".join(f"<li>{p['name']} — {p['price']:,}원</li>" for p in PRODUCTS)
                status = self.send(200, f"<h1>OSI Shop {VERSION}</h1><p>pod: {HOSTNAME}</p><ul>{rows}</ul>", "text/html; charset=utf-8")
            else:
                status = self.send(404, {"error": "not found"})
        except Exception as e:
            logx(logging.ERROR, "request failed", path=path, error=str(e))
            try: status = self.send(500, {"error": "internal"})
            except Exception: pass
        finally:
            dt = time.time() - t0
            if path not in ("/healthz", "/readyz", "/metrics"):
                observe(method, path if path.startswith("/api/") or path == "/" else "other", status, dt)
                logx(logging.ERROR if status >= 500 else logging.INFO, "request",
                     method=method, path=path, status=status, ms=round(dt * 1000, 1))
            else:
                logx(logging.DEBUG, "probe", path=path, status=status)

    def do_GET(self): self.handle_one("GET")
    def do_POST(self): self.handle_one("POST")

# ---- 시작 · 우아한 종료
def main():
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    srv.daemon_threads = True

    def on_term(signum, frame):
        # 1) readiness를 실패로 바꿔 Service에서 빠지게 하고
        # 2) DRAIN_SECONDS 동안 남은 요청을 처리한 뒤 종료
        logx(logging.WARNING, "SIGTERM received, draining", drain_seconds=DRAIN_SECONDS)
        draining.set()
        threading.Thread(target=lambda: (time.sleep(DRAIN_SECONDS), srv.shutdown()), daemon=True).start()

    signal.signal(signal.SIGTERM, on_term)
    logx(logging.INFO, "started", port=PORT, redis=REDIS_HOST or "memory", error_rate=ERROR_RATE, slow_ms=SLOW_MS)
    srv.serve_forever()
    logx(logging.INFO, "stopped")

if __name__ == "__main__":
    main()
