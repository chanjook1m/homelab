"""아주 작은 WebSocket(RFC 6455) 구현 — 표준 라이브러리만 사용 (학습용).
서버·클라이언트 공용: 핸드셰이크 키 계산, 프레임 읽기/쓰기, 종료 코드."""
import asyncio, base64, hashlib, os, struct

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
OP_TEXT, OP_CLOSE, OP_PING, OP_PONG = 0x1, 0x8, 0x9, 0xA


def accept_key(key: str) -> str:
    """Sec-WebSocket-Accept = base64(SHA1(클라이언트 키 + 고정 GUID))"""
    return base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()


async def read_frame(reader: asyncio.StreamReader):
    """프레임 하나를 읽어 (opcode, payload) 반환. 클라이언트→서버 프레임은 마스킹돼 있음."""
    b1, b2 = await reader.readexactly(2)
    opcode, masked, ln = b1 & 0x0F, b2 & 0x80, b2 & 0x7F
    if ln == 126:
        ln = struct.unpack("!H", await reader.readexactly(2))[0]
    elif ln == 127:
        ln = struct.unpack("!Q", await reader.readexactly(8))[0]
    mask = await reader.readexactly(4) if masked else b""
    data = await reader.readexactly(ln)
    if masked:
        data = bytes(c ^ mask[i % 4] for i, c in enumerate(data))
    return opcode, data


def build_frame(opcode: int, payload: bytes = b"", mask: bool = False) -> bytes:
    """서버는 마스킹하지 않고, 클라이언트는 반드시 마스킹합니다(RFC 6455 5.3)."""
    head = bytes([0x80 | opcode])
    ln = len(payload)
    mbit = 0x80 if mask else 0
    if ln < 126:
        head += bytes([mbit | ln])
    elif ln < 65536:
        head += bytes([mbit | 126]) + struct.pack("!H", ln)
    else:
        head += bytes([mbit | 127]) + struct.pack("!Q", ln)
    if mask:
        key = os.urandom(4)
        payload = bytes(c ^ key[i % 4] for i, c in enumerate(payload))
        head += key
    return head + payload


def close_payload(code: int, reason: str = "") -> bytes:
    return struct.pack("!H", code) + reason.encode()


def close_code(payload: bytes) -> int:
    return struct.unpack("!H", payload[:2])[0] if len(payload) >= 2 else 1005
