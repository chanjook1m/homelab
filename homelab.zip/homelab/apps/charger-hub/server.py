"""charger-hub: 충전기(OCPP 흉내) WebSocket 서버 — ChargeOps 실험을 집에서 재현하는 학습용 앱.

경로
  GET /ocpp/<충전기ID>  WebSocket 업그레이드. 텍스트 메시지를 받으면 {"ack": ...}로 응답
  GET /healthz          살아 있나(liveness) — 가볍게, 의존성 없이
  GET /readyz           받을 준비가 됐나(readiness) — 종료 중이면 503
  GET /metrics          Prometheus 지표 (Pod별 연결 수, 누적 접속, 종료 코드별 개수)

종료(SIGTERM): 새 접속 거부 → DRAIN_SECONDS에 걸쳐 연결을 1012(Service Restart)로 하나씩 닫음 → 종료
환경변수: PORT(8080) DRAIN_SECONDS(20) MAX_CONN(0=무제한) SLOW_HEALTH_MS(0)
"""
import asyncio, json, os, signal, socket, time
from wsproto import OP_CLOSE, OP_PING, OP_PONG, OP_TEXT, accept_key, build_frame, close_code, close_payload, read_frame

PORT = int(os.getenv("PORT", "8080"))
DRAIN_SECONDS = float(os.getenv("DRAIN_SECONDS", "20"))
MAX_CONN = int(os.getenv("MAX_CONN", "0"))
SLOW_HEALTH_MS = int(os.getenv("SLOW_HEALTH_MS", "0"))
POD = socket.gethostname()

conns = {}                  # writer -> charger id
stats = {"accepted": 0, "rejected": 0, "messages": 0, "closed": {}}
draining = asyncio.Event()


def log(msg, **kw):
    print(json.dumps({"t": time.strftime("%H:%M:%S"), "pod": POD, "msg": msg, **kw}, ensure_ascii=False), flush=True)


def metrics() -> str:
    lines = [
        "# TYPE ws_active_connections gauge", f'ws_active_connections{{pod="{POD}"}} {len(conns)}',
        "# TYPE ws_accepted_total counter", f'ws_accepted_total{{pod="{POD}"}} {stats["accepted"]}',
        "# TYPE ws_rejected_total counter", f'ws_rejected_total{{pod="{POD}"}} {stats["rejected"]}',
        "# TYPE ws_messages_total counter", f'ws_messages_total{{pod="{POD}"}} {stats["messages"]}',
        "# TYPE ws_closed_total counter",
    ]
    lines += [f'ws_closed_total{{pod="{POD}",code="{c}"}} {n}' for c, n in sorted(stats["closed"].items())]
    return "\n".join(lines) + "\n"


async def http_reply(writer, status, body, ctype="text/plain"):
    data = body.encode()
    writer.write(f"HTTP/1.1 {status}\r\nContent-Type: {ctype}\r\nContent-Length: {len(data)}\r\nConnection: close\r\n\r\n".encode() + data)
    await writer.drain()
    writer.close()


async def handle(reader, writer):
    try:
        request = (await reader.readuntil(b"\r\n\r\n")).decode(errors="replace")
    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, ConnectionError):
        writer.close(); return
    first, *hdr = request.split("\r\n")
    parts = first.split(" ")
    path = parts[1] if len(parts) > 1 else "/"
    headers = {k.strip().lower(): v.strip() for k, _, v in (h.partition(":") for h in hdr if ":" in h)}

    if path == "/healthz":
        if SLOW_HEALTH_MS:
            await asyncio.sleep(SLOW_HEALTH_MS / 1000)
        return await http_reply(writer, "200 OK", "alive")
    if path == "/readyz":
        return await http_reply(writer, "503 Service Unavailable" if draining.is_set() else "200 OK",
                                "draining" if draining.is_set() else "ready")
    if path == "/metrics":
        return await http_reply(writer, "200 OK", metrics(), "text/plain; version=0.0.4")
    if not path.startswith("/ocpp/") or headers.get("upgrade", "").lower() != "websocket":
        return await http_reply(writer, "404 Not Found", "not found")
    if draining.is_set() or (MAX_CONN and len(conns) >= MAX_CONN):
        stats["rejected"] += 1
        return await http_reply(writer, "503 Service Unavailable", "busy")

    cid = path.split("/", 2)[2] or "unknown"
    writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                  f"Sec-WebSocket-Accept: {accept_key(headers.get('sec-websocket-key', ''))}\r\n\r\n").encode())
    await writer.drain()
    conns[writer] = cid
    stats["accepted"] += 1
    code = 1006
    try:
        while True:
            op, data = await read_frame(reader)
            if op == OP_TEXT:
                stats["messages"] += 1
                writer.write(build_frame(OP_TEXT, json.dumps({"ack": data.decode(errors="replace")[:64], "pod": POD}).encode()))
                await writer.drain()
            elif op == OP_PING:
                writer.write(build_frame(OP_PONG, data)); await writer.drain()
            elif op == OP_CLOSE:
                code = close_code(data)
                writer.write(build_frame(OP_CLOSE, data[:2])); await writer.drain()
                break
    except (asyncio.IncompleteReadError, ConnectionError):
        code = 1006
    finally:
        if conns.pop(writer, None) is not None:
            stats["closed"][code] = stats["closed"].get(code, 0) + 1
        writer.close()


async def drain_and_exit(server):
    """종료 신호 처리: 새 접속 막기 → 연결을 DRAIN_SECONDS에 걸쳐 1012로 나눠 닫기"""
    draining.set()
    server.close()
    targets = list(conns)
    log("SIGTERM — drain 시작", connections=len(targets), drain_seconds=DRAIN_SECONDS)
    gap = DRAIN_SECONDS / max(len(targets), 1)
    for w in targets:
        if w in conns:
            try:
                w.write(build_frame(OP_CLOSE, close_payload(1012, "service restart")))
                await w.drain()
            except ConnectionError:
                pass
            stats["closed"][1012] = stats["closed"].get(1012, 0) + 1
            conns.pop(w, None)
            w.close()
        await asyncio.sleep(gap)
    log("drain 완료")


async def main():
    server = await asyncio.start_server(handle, "0.0.0.0", PORT, backlog=1024)
    loop = asyncio.get_running_loop()
    done = asyncio.Event()

    def on_term():
        async def run():
            await drain_and_exit(server)
            done.set()
        loop.create_task(run())

    loop.add_signal_handler(signal.SIGTERM, on_term)
    loop.add_signal_handler(signal.SIGINT, on_term)
    log("started", port=PORT, drain_seconds=DRAIN_SECONDS, max_conn=MAX_CONN)
    async with server:
        await done.wait()


if __name__ == "__main__":
    asyncio.run(main())
