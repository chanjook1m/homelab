"""charger-load: 충전기 N대를 흉내 내는 WebSocket 부하 도구 (표준 라이브러리만).

python3 loadgen.py --url ws://HOST:PORT --chargers 200 --duration 120 [--rate 50] [--heartbeat 30] [--jitter 0]
- 접속: 초당 --rate 개씩 연결 (몰림 정도 조절)
- 유지: --heartbeat 초마다 메시지 1개
- 끊기면: 1012(정상 재시작)는 --jitter 초 안에서 무작위로 기다린 뒤, 그 외는 1~2초 뒤 재접속
- 5초마다 한 줄 요약, 끝나면 재접속 시간 p50/p95/최대와 종료 코드 분포 출력 (--out 으로 JSONL 저장)
"""
import argparse, asyncio, base64, json, os, random, statistics, time
from urllib.parse import urlparse
from wsproto import OP_CLOSE, OP_TEXT, build_frame, close_code, read_frame

S = {"connected": 0, "fail": 0, "codes": {}, "reconnect_s": [], "pods": {}}


async def connect(host, port, path):
    reader, writer = await asyncio.open_connection(host, port)
    key = base64.b64encode(os.urandom(16)).decode()
    writer.write((f"GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                  f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
    await writer.drain()
    resp = (await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 5)).decode()
    if " 101 " not in resp.split("\r\n")[0]:
        writer.close()
        raise ConnectionError(resp.split("\r\n")[0])
    return reader, writer


async def charger(i, a, stop):
    u = urlparse(a.url)
    path = f"/ocpp/CHG-{i:05d}"
    lost_at = None
    while not stop.is_set():
        try:
            reader, writer = await connect(u.hostname, u.port or 80, path)
        except (OSError, ConnectionError, asyncio.TimeoutError):
            S["fail"] += 1
            await asyncio.sleep(1 + random.random())
            continue
        S["connected"] += 1
        if lost_at is not None:
            S["reconnect_s"].append(time.monotonic() - lost_at)
            lost_at = None
        code = 1006
        try:
            writer.write(build_frame(OP_TEXT, b'["BootNotification"]', mask=True)); await writer.drain()
            while not stop.is_set():
                try:
                    op, data = await asyncio.wait_for(read_frame(reader), a.heartbeat)
                except asyncio.TimeoutError:
                    writer.write(build_frame(OP_TEXT, b'["Heartbeat"]', mask=True)); await writer.drain()
                    continue
                if op == OP_TEXT:
                    pod = json.loads(data).get("pod", "?")
                    S["pods"][i] = pod
                elif op == OP_CLOSE:
                    code = close_code(data)
                    break
        except (asyncio.IncompleteReadError, ConnectionError):
            code = 1006
        finally:
            S["connected"] -= 1
            S["pods"].pop(i, None)
            writer.close()
        if stop.is_set():
            break
        S["codes"][code] = S["codes"].get(code, 0) + 1
        lost_at = time.monotonic()
        await asyncio.sleep(random.uniform(0, a.jitter) if code == 1012 else 1 + random.random())


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(round(p / 100 * (len(xs) - 1))))] if xs else 0.0


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True); p.add_argument("--chargers", type=int, default=100)
    p.add_argument("--rate", type=float, default=50); p.add_argument("--heartbeat", type=float, default=30)
    p.add_argument("--jitter", type=float, default=0); p.add_argument("--duration", type=float, default=60)
    p.add_argument("--out", default="")
    a = p.parse_args()
    stop = asyncio.Event()
    tasks = []
    for i in range(a.chargers):
        tasks.append(asyncio.create_task(charger(i, a, stop)))
        await asyncio.sleep(1 / a.rate)
    t0 = time.monotonic()
    out = open(a.out, "a") if a.out else None
    while time.monotonic() - t0 < a.duration:
        await asyncio.sleep(5)
        per_pod = {}
        for pod in S["pods"].values():
            per_pod[pod] = per_pod.get(pod, 0) + 1
        row = {"t": time.strftime("%H:%M:%S"), "connected": S["connected"], "fail": S["fail"], "codes": S["codes"], "per_pod": per_pod}
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if out:
            out.write(json.dumps(row) + "\n"); out.flush()
    stop.set()
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    r = S["reconnect_s"]
    summary = {"reconnects": len(r), "p50_s": round(pct(r, 50), 3), "p95_s": round(pct(r, 95), 3),
               "max_s": round(max(r), 3) if r else 0, "codes": S["codes"], "connect_fail": S["fail"]}
    print("SUMMARY", json.dumps(summary, ensure_ascii=False))
    if r:
        print("mean_s", round(statistics.mean(r), 3))


if __name__ == "__main__":
    asyncio.run(main())
