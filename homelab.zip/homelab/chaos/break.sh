#!/usr/bin/env bash
# 고장 만들기 스크립트 — 일부러 고장 내고, 증상만 보고 원인을 찾는 연습
# 사용: ./chaos/break.sh list | ./chaos/break.sh <번호> | ./chaos/break.sh restore <번호>
# 규칙: 고장 낸 뒤에는 이 스크립트를 다시 보지 말고 kubectl/로그만으로 찾으세요. 찾은 과정은 troubleshooting/TEMPLATE.md 형식으로 기록.
set -euo pipefail
NS=${NS:-shop}
W=${WORKER:-w1}

usage() {
  cat <<'L'
 1  (노드)    워커의 kubelet 중지                     → 노드 NotReady, Pod 재배치까지 걸리는 시간 관찰
 2  (노드)    워커의 containerd 중지                  → 노드 상태는? 기존 Pod는?
 3  (DNS)     CoreDNS 레플리카 0                       → 서비스 이름 해석 실패, IP로는 접속됨
 4  (네트워크) 기본 거부 NetworkPolicy를 shop에 추가     → 같은 노드 Pod끼리도 통신 실패
 5  (이미지)  존재하지 않는 태그로 이미지 변경           → ImagePullBackOff, 롤아웃 중단 (기존 Pod는 유지됨)
 6  (자원)    메모리 limit 16Mi로 줄이기               → OOMKilled, 재시작 횟수 증가
 7  (프로브)  readiness 경로를 /nope으로                → Running인데 트래픽 안 받음 (Endpoints 비어 있음)
 8  (스케줄)  워커 2대 모두 cordon 후 Pod 삭제          → Pending, 이벤트 메시지 읽기
 9  (인증서)  cert-manager 인증서 Secret 삭제           → 재발급 흐름 관찰
10  (시간)    워커 시계를 2시간 어긋나게                → 인증서/토큰 오류 양상
11  (디스크)  워커 디스크 채우기 (DiskPressure)         → 축출(eviction) 순서 관찰
12  (Ingress) Service selector 오타                    → 502/503 vs 404 구분
L
}

case "${1:-list}" in
  list) usage ;;
  1) multipass exec "$W" -- sudo systemctl stop kubelet ;;
  2) multipass exec "$W" -- sudo systemctl stop containerd ;;
  3) kubectl -n kube-system scale deploy coredns --replicas=0 ;;
  4) kubectl -n "$NS" apply -f - <<'Y'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: chaos-deny-all}
spec: {podSelector: {}, policyTypes: [Ingress, Egress]}
Y
  ;;
  5) kubectl -n "$NS" set image deploy/shop-api api=harbor.home.arpa/team/osi-shop:does-not-exist ;;
  6) kubectl -n "$NS" set resources deploy/shop-api -c api --limits=memory=16Mi ;;
  7) kubectl -n "$NS" patch deploy shop-api --type=json -p='[{"op":"replace","path":"/spec/template/spec/containers/0/readinessProbe/httpGet/path","value":"/nope"}]' ;;
  8) kubectl cordon w1 w2 && kubectl -n "$NS" delete pod -l app=shop-api ;;
  9) kubectl -n "$NS" delete secret shop-home-tls ;;
  10) multipass exec "$W" -- sudo bash -c 'timedatectl set-ntp false && date -s "+2 hours"' ;;
  11) multipass exec "$W" -- sudo fallocate -l "$(multipass exec "$W" -- df --output=avail -B1 / | tail -1 | awk '{print int($1*0.95)}')" /var/tmp/fill ;;
  12) kubectl -n "$NS" patch svc shop-api -p '{"spec":{"selector":{"app":"shop-apj"}}}' ;;
  restore)
    case "${2:?번호}" in
      1) multipass exec "$W" -- sudo systemctl start kubelet ;;
      2) multipass exec "$W" -- sudo systemctl start containerd ;;
      3) kubectl -n kube-system scale deploy coredns --replicas=2 ;;
      4) kubectl -n "$NS" delete netpol chaos-deny-all ;;
      5|6|7) kubectl -n "$NS" rollout undo deploy/shop-api ;;
      8) kubectl uncordon w1 w2 ;;
      9) echo "cert-manager가 자동 재발급합니다: kubectl -n $NS get certificate -w" ;;
      10) multipass exec "$W" -- sudo timedatectl set-ntp true ;;
      11) multipass exec "$W" -- sudo rm -f /var/tmp/fill ;;
      12) kubectl -n "$NS" patch svc shop-api -p '{"spec":{"selector":{"app":"shop-api"}}}' ;;
      *) echo "알 수 없는 번호"; exit 1 ;;
    esac ;;
  *) usage; exit 1 ;;
esac
