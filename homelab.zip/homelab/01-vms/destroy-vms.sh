#!/usr/bin/env bash
# VM 전부 삭제(재구축 연습용). 되돌릴 수 없습니다.
set -euo pipefail
read -r -p "cp1·w1·w2를 삭제할까요? [y/N] " a
[ "$a" = "y" ] || exit 0
multipass delete cp1 w1 w2 2>/dev/null || true
multipass purge
