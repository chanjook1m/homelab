#!/usr/bin/env bash
# VM 3대(cp1 컨트롤 플레인, w1·w2 워커)를 만들고 Ansible 인벤토리를 생성합니다.
# 사용: MEM_PROFILE=16 bash 01-vms/create-vms.sh   (8 / 16 / 24)
set -euo pipefail
cd "$(dirname "$0")"

PROFILE="${MEM_PROFILE:-16}"
IMAGE="${IMAGE:-24.04}"
case "$PROFILE" in
  8)  NODES=("cp1:2:3G" "w1:2:2.5G") ;;
  16) NODES=("cp1:2:3G" "w1:2:3.5G" "w2:2:3.5G") ;;
  24) NODES=("cp1:2:4G" "w1:3:6G" "w2:3:6G") ;;
  *)  echo "MEM_PROFILE은 8, 16, 24 중 하나" >&2; exit 1 ;;
esac

KEY="$HOME/.ssh/homelab_ed25519"
[ -f "$KEY" ] || ssh-keygen -t ed25519 -N "" -f "$KEY" -C homelab
sed "s|__SSH_PUBKEY__|$(cat "$KEY.pub")|" cloud-init.yaml > /tmp/homelab-cloud-init.yaml

for spec in "${NODES[@]}"; do
  IFS=: read -r name cpus mem <<<"$spec"
  if multipass info "$name" >/dev/null 2>&1; then
    echo "$name 이미 있음 — 건너뜀"; continue
  fi
  multipass launch "$IMAGE" --name "$name" --cpus "$cpus" --memory "$mem" --disk 20G \
    --cloud-init /tmp/homelab-cloud-init.yaml
done

bash ./gen-inventory.sh
multipass list
