#!/usr/bin/env bash
# multipass list의 IP로 Ansible 인벤토리(ansible/inventory.ini)를 만듭니다.
# VM IP가 바뀌면(재부팅 후 DHCP) 다시 실행하세요. — 1주차 고장 내기 과제와 연결
set -euo pipefail
cd "$(dirname "$0")"
OUT=../ansible/inventory.ini
ip_of() { multipass info "$1" --format json | jq -r --arg n "$1" '.info[$n].ipv4[0]'; }

{
  echo "[control_plane]"
  echo "cp1 ansible_host=$(ip_of cp1)"
  echo
  echo "[workers]"
  for w in w1 w2; do
    if multipass info "$w" >/dev/null 2>&1; then echo "$w ansible_host=$(ip_of "$w")"; fi
  done
  echo
  echo "[k8s:children]"
  echo "control_plane"
  echo "workers"
  echo
  echo "[k8s:vars]"
  echo "ansible_user=ubuntu"
  echo "ansible_ssh_private_key_file=~/.ssh/homelab_ed25519"
} > "$OUT"
echo "생성: $OUT"; cat "$OUT"
