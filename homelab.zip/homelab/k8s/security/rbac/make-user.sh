#!/usr/bin/env bash
# 개발자용 kubeconfig 만들기: 쿠버네티스 CSR API로 클라이언트 인증서를 발급 (사용자 계정 = 인증서)
# 사용: bash make-user.sh alice team-hello   → alice.kubeconfig 생성
set -euo pipefail
USER_NAME=${1:?사용자 이름}; GROUP=${2:?그룹 이름}
openssl genrsa -out "$USER_NAME.key" 2048 2>/dev/null
openssl req -new -key "$USER_NAME.key" -subj "/CN=$USER_NAME/O=$GROUP" -out "$USER_NAME.csr"
cat <<YAML | kubectl apply -f -
apiVersion: certificates.k8s.io/v1
kind: CertificateSigningRequest
metadata: {name: $USER_NAME}
spec:
  request: $(base64 < "$USER_NAME.csr" | tr -d '\n')
  signerName: kubernetes.io/kube-apiserver-client
  expirationSeconds: 604800
  usages: [client auth]
YAML
kubectl certificate approve "$USER_NAME"
kubectl get csr "$USER_NAME" -o jsonpath='{.status.certificate}' | base64 -d > "$USER_NAME.crt"
SERVER=$(kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}')
kubectl config view --raw --minify -o jsonpath='{.clusters[0].cluster.certificate-authority-data}' | base64 -d > ca.crt
KUBECONFIG="$USER_NAME.kubeconfig" kubectl config set-cluster homelab --server="$SERVER" --certificate-authority=ca.crt --embed-certs=true >/dev/null
KUBECONFIG="$USER_NAME.kubeconfig" kubectl config set-credentials "$USER_NAME" --client-certificate="$USER_NAME.crt" --client-key="$USER_NAME.key" --embed-certs=true >/dev/null
KUBECONFIG="$USER_NAME.kubeconfig" kubectl config set-context default --cluster=homelab --user="$USER_NAME" >/dev/null
KUBECONFIG="$USER_NAME.kubeconfig" kubectl config use-context default >/dev/null
rm -f "$USER_NAME.csr" ca.crt
echo "생성: $USER_NAME.kubeconfig (7일 유효)"
echo "확인: KUBECONFIG=$USER_NAME.kubeconfig kubectl -n app-hello auth can-i get secrets   # no 여야 정상"
