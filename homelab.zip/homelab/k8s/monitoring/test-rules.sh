#!/usr/bin/env bash
# 알림 규칙도 코드처럼 테스트: PrometheusRule에서 groups만 뽑아 promtool로 문법 검사 + 단위 테스트
# 필요: promtool (Prometheus 릴리스에 포함), yq
set -euo pipefail
cd "$(dirname "$0")"
yq '{"groups": .spec.groups}' shop-slo-rules.yaml > tests/shop-slo-rules.plain.yml
promtool check rules tests/shop-slo-rules.plain.yml
promtool test rules tests/shop-slo-test.yml
