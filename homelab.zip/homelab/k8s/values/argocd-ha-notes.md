# Argo CD HA (5주차 비교 과제)

- 기본 설치(install.yaml): 구성 요소가 각 1개. 컨트롤러나 Redis가 죽으면 동기화가 멈춥니다(배포 중인 앱은 계속 돌아감).
- HA 설치(ha/install.yaml): repo-server·server 여러 개, Redis는 Sentinel 3개. **노드 3대 이상**에 흩어져야 의미가 있습니다.
- 홈랩(워커 2대)에서는 컨트롤 플레인 노드에도 Pod가 뜨게 taint를 풀어야 3곳에 퍼집니다:
  `kubectl taint nodes cp1 node-role.kubernetes.io/control-plane:NoSchedule-`
- 비교할 것: 메모리 사용량(kubectl top), 컨트롤러 Pod 하나 삭제 시 동기화 중단 시간.
- 결론을 면접에서: "HA는 장애 허용 수(노드 1대)만큼 자원을 더 쓰는 선택이고, 홈랩 3노드에선 메모리가 약 x배 들었다"처럼 숫자로.
