# 트러블슈팅 기록 목록

8주 동안 최소 30건이 목표입니다. 계층이 고르게 분포할수록 "인프라 전체를 이해한다"는 근거가 됩니다.

| 번호 | 제목 | 계층 | 주차 | 해결 시간 | 핵심 명령 |
|---|---|---|---|---|---|
| TS-001 | (예) kubeadm init 후 노드 NotReady — CNI 미설치 | CNI | 1 | 10분 | `kubectl describe node`, `crictl ps` |
| TS-002 | (예) Service selector 오타로 EndpointSlice 비어 있음 | Service | 2 | 15분 | `kubectl get endpointslice` |

## 계층별 개수 (주말마다 갱신)
| 노드 | 런타임 | CNI | DNS | Service | Ingress | 인증서 | 앱 | CI/CD | GitOps | 권한 | 클라우드 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | | |
