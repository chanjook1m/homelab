# Crossplane — 쿠버네티스 YAML로 AWS 리소스 만들기 (7주차, 클라우드 k3s 노드에서)

왜 EC2(클라우드 k3s)에 설치하나: EC2의 인스턴스 프로파일(terraform/aws/ec2_k3s.tf)로 **키 없이** AWS API를 부를 수 있기 때문.
홈랩(Mac) 쪽에 설치하면 AWS 액세스 키를 Secret으로 넣어야 해서 보안상 불리 → 이 선택 자체가 면접 답변 소재.

순서
1. `helm install crossplane crossplane-stable/crossplane -n crossplane-system --create-namespace`
2. `kubectl apply -f 01-provider.yaml` (ECR 프로바이더만 — 전체 AWS 프로바이더는 CRD 수백 개라 메모리 2GB 노드가 버거움)
3. `kubectl apply -f 02-xrd.yaml -f 03-composition.yaml`
4. 개발자는 `04-claim-example.yaml`처럼 4줄만 작성 → ECR 저장소 생성, 수명 주기 정책까지 자동

버전 메모: 아래 파일은 Crossplane v1 방식(Claim 사용)으로 작성했습니다. v2에서도 호환 모드로 동작하지만,
설치 시점의 공식 문서에서 XRD/Composition API 버전을 한 번 확인하세요. [공식 문서 기준]
