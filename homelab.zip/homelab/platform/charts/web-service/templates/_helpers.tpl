{{- define "ws.labels" -}}
app.kubernetes.io/name: {{ .Values.app }}
app.kubernetes.io/managed-by: platform-golden-path
platform.homelab/app: {{ .Values.app }}
{{- end -}}
{{- define "ws.selector" -}}
app.kubernetes.io/name: {{ .Values.app }}
{{- end -}}
{{- define "ws.host" -}}
{{- default (printf "%s.%s" .Values.app .Values.platform.domain) .Values.host -}}
{{- end -}}
