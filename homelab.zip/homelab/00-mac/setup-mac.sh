#!/usr/bin/env bash
# 1주차 1일: Mac mini에 필요한 도구 설치 (Apple Silicon / Intel 공통)
# 사용: bash 00-mac/setup-mac.sh
set -euo pipefail

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew가 없습니다. https://brew.sh 의 설치 명령을 먼저 실행하세요." >&2
  exit 1
fi

# VM(Multipass), 컨테이너(Colima+Docker CLI), 쿠버네티스 도구, IaC, 보안 도구
brew install --cask multipass
brew install colima docker docker-compose \
  kubectl helm k9s jq yq \
  ansible terraform awscli \
  cilium-cli hubble \
  argocd kubeseal cosign trivy \
  tailscale cloudflared

echo
echo "설치된 버전 (README의 버전 기록 표에 적어 두세요)"
multipass version | head -1
kubectl version --client 2>/dev/null | head -1
helm version --short
ansible --version | head -1
terraform version | head -1
