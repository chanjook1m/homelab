#!/usr/bin/env bash
# 5주차: 배포 상태만 담는 GitOps 저장소(homelab-gitops)를 이 저장소에서 뽑아 만듭니다.
# 왜 나누나: CI가 배포 저장소에 커밋해도 앱 빌드가 다시 돌지 않고(무한 루프 방지),
#           "무엇이 배포돼 있나"와 "코드가 어떻게 바뀌었나"의 기록·권한을 분리하기 위해.
# 사용: bash scripts/make-gitops-repo.sh ../homelab-gitops
set -euo pipefail
SRC=$(cd "$(dirname "$0")/.." && pwd)
DST=${1:?만들 폴더 경로}
mkdir -p "$DST/argocd/apps" "$DST/k8s"
cp -R "$SRC/k8s/argocd/apps/." "$DST/argocd/apps/"
cp "$SRC/k8s/argocd/appset-golden-path.yaml" "$DST/argocd/apps/"
cp -R "$SRC/k8s/apps" "$DST/k8s/"
cp -R "$SRC/platform" "$SRC/teams" "$DST/"
cd "$DST"
[ -d .git ] || git init -q -b main
git add -A
echo "준비됨: $DST — GitHub에 homelab-gitops(Private)로 만들고 push 하세요."
echo "다음: k8s/argocd/root-app.yaml 의 repoURL 을 그 주소로 바꾼 뒤 kubectl apply"
