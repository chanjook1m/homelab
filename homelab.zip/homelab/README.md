# Mac mini 홈랩 — GitOps 셀프서비스 플랫폼

개발자가 `teams/<팀>/values.yaml` 다섯 줄을 커밋하면 Namespace·Deployment·Service·Ingress(TLS)·HPA·PDB·NetworkPolicy·Grafana 대시보드가
자동으로 생기고, 서명 안 된 이미지나 `latest` 태그는 클러스터가 거부하는 플랫폼입니다. 8주 가이드 문서와 함께 씁니다.

## 구성
```
Mac mini (Apple Silicon)
 └─ Multipass VM 3대 (Ubuntu 24.04): cp1 / w1 / w2   ← Ansible + kubeadm
     ├─ Cilium(CNI) + Hubble   MetalLB   Traefik   cert-manager(사설 CA)
     ├─ Harbor(또는 Zot)  ← Jenkins / GitHub Actions 가 빌드·스캔·서명 후 푸시
     ├─ Argo CD (ApplicationSet = 골든 패스)   Argo Rollouts(카나리)
     ├─ Kyverno(정책)  PSA restricted  RBAC  OpenBao + External Secrets  Falco
     └─ kube-prometheus-stack  Loki  OpenCost
 └─ Cloudflare Tunnel(포트 개방 없이 공개)   Tailscale(관리 접속)
AWS (개인 계정, 예산 알림 $10)
 └─ Terraform: VPC(NAT 없음) · GitHub OIDC 역할 · ECR · CloudTrail · Budgets
 └─ EC2 t4g.small k3s (실습 때만) ← Argo CD 멀티 클러스터, Crossplane
```

## 폴더
| 폴더 | 내용 | 주차 |
|---|---|---|
| 00-mac | Mac 도구 설치, 상시 가동 설정 | 0 |
| 01-vms | Multipass VM 생성/삭제, 인벤토리 생성 | 1 |
| ansible | kubeadm 클러스터 구축·업그레이드·초기화 | 1, 8 |
| k8s/platform | MetalLB, Traefik, cert-manager, Cloudflare Tunnel | 2 |
| app, apps/charger-hub, k8s/apps | 실습 앱 2개 (HTTP 쇼핑 API, WebSocket 충전기 허브) | 2, 5 |
| ci, .github | Jenkins(강의 구조), GitHub Actions(OIDC→ECR), 플랫폼 PR 검사 | 4, 7 |
| k8s/argocd, k8s/rollouts | GitOps, 골든 패스 ApplicationSet, 카나리 | 5 |
| platform/charts/web-service, teams | 골든 패스 Helm 차트, 팀별 values | 5 |
| k8s/security | Kyverno, Cilium 정책, RBAC, kube-bench | 3, 6 |
| k8s/secrets, k8s/values | OpenBao+ESO, Falco, 모니터링, Harbor, OpenCost | 4, 6, 8 |
| k8s/monitoring | SLO 오류 예산 소진율 알림 + promtool 테스트 | 8 |
| scripts | GitOps 저장소 분리 스크립트 | 5 |
| terraform/aws, crossplane | AWS 연동 | 7 |
| chaos | 고장 만들기 12종 | 매주 |
| troubleshooting | 기록 양식과 목록 | 매주 |

## 버전 기준 (2026-11 작성)
| 구성 요소 | 기준 | 메모 |
|---|---|---|
| Kubernetes | v1.36 → 8주차에 v1.37로 업그레이드 | pkgs.k8s.io 마이너별 저장소 |
| Ubuntu | 24.04 LTS | cgroup v2 |
| Cilium | 설치 시점 안정 버전 | kube-proxy 유지(iptables 학습용) |
| Ingress | Traefik v3 | ingress-nginx는 2026-03 지원 종료 |
| Helm | 4.x | |
| Crossplane | v2 (파일은 v1 호환 방식) | |

설치 직전에 각 프로젝트의 공식 문서에서 최신 버전을 확인하고 고정하세요.

## 검증 범위 (정직하게)
이 저장소는 Linux 컨테이너 환경의 k3s에서 아래를 실제로 실행해 확인했습니다.
- 골든 패스 차트 렌더링 + PSA restricted 통과, values.schema.json 검증(`latest` 거부)
- Kyverno 정책 테스트 10/10, RBAC(CSR로 발급한 사용자) 권한 확인, NetworkPolicy 허용/차단
- charger-hub WebSocket 드레인·재접속 쏠림 재현, chaos 시나리오 4·7·12
- SLO 알림 규칙 promtool 문법 검사 + 단위 테스트, 앱 단위 테스트
- 셸 스크립트 shellcheck, Ansible syntax-check, GitHub Actions actionlint, Terraform fmt, 매니페스트 서버 측 dry-run

다음은 실행 환경 제약으로 **공식 문서 기준으로 작성**했고 직접 실행하지 못했습니다: Mac/Multipass 단계, kubeadm 실제 설치,
Terraform plan/apply(프로바이더 다운로드 불가), Jenkins 실행, Harbor/Argo CD/Cilium 등 클러스터 내 설치, Crossplane.
처음 실행할 때 나오는 오류는 그 자체로 트러블슈팅 기록 소재입니다.

## 비용
- 홈랩 내부: 0원 (전기료 별도, Mac mini 유휴 약 5~7W)
- 도메인: 연 1~2만원 (Cloudflare Registrar 원가)
- AWS 8주: EC2를 실습 때만 켜면 약 1~3만원. `enable_ec2=false`로 끄는 습관이 핵심
